<?php

$conn = mysqli_connect('localhost','root','Vishal123','myshopping_cart') or die("Connection Fail");

?>